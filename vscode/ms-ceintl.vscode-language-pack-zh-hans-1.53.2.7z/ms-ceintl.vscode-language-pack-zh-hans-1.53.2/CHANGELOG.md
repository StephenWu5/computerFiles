# Change Log
All notable changes to the "vscode-language-pack-zh-hans" language pack will be documented in this file.

## [Released]
* February 3, 2021 - Release for VS Code 1.53
* December 9, 2020 - Release for VS Code 1.52
* November 4, 2020 - Release for VS Code 1.51
* October 7, 2020 - Release for VS Code 1.50
* September 9, 2020 - Release for VS Code 1.49
* August 12, 2020 -  Release for VS Code 1.48
* July 8, 2020 -  Release for VS Code 1.47
* June 10, 2020 -  Release for VS Code 1.46
* May 7, 2020 -  Release for VS Code 1.45
* April 7, 2020 -  Release for VS Code 1.44
* March 3, 2020 -  Release for VS Code 1.43
* February 5, 2020 -  Release for VS Code 1.42
* December 16, 2019 -  Release for VS Code 1.41
* November 6, 2019 -  Release for VS Code 1.40
* October 9, 2019 - Release for VS Code 1.39
* September 4, 2019 - Release for VS Code 1.38
* August 7, 2019 - Release for VS Code 1.37
* July 3, 2019 - Release for VS Code 1.36
* June 6, 2019 - Release for VS Code 1.35
* May 15, 2019 - Release for VS Code 1.34
* April 3, 2019 - Release for VS Code 1.33
* March 6, 2019 - Release for VS Code 1.32
* February 6, 2019 - Release for VS Code 1.31
* December 12, 2018 - Release for VS Code 1.30
* November 7, 2018 - Release for VS Code 1.29
* October 3, 2018 - Release for VS Code 1.28
* September 5, 2018 - Release for VS Code 1.27
* August 8, 2018 - Release for VS Code 1.26
* July 5, 2018 - Release for VS Code 1.25
* June 6, 2018 - Release for VS Code 1.24
* May 5, 2018 - Release for VS Code 1.23
* April 16, 2018 - Initial release
